<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7f49d279c0b676a058d060746b939d1e',
      'native_key' => NULL,
      'filename' => 'modCategory/e7104408f08829e09d6a98fd900895c4.vehicle',
    ),
  ),
);